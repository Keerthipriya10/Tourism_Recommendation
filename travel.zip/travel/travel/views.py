from django.shortcuts import render
from django.shortcuts import render, redirect
import requests
import sys
from subprocess import run,PIPE
from register.models import Place
from django.views import generic
from django.contrib.auth.models import User
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.contrib.auth.decorators import login_required
from register.forms import RecommendForm
def wt_home(request):
	return render(request,'wt_home.html')
def log(request):
	return render(request,'login_template.html')
def home(request):
	return render(request,'wt_home.html')
def base(request):
	return render(request,'wt_base.html')

def search_titles(request,):
    print("inside search_titles")

    if(request.method=="POST"):
        search_text=request.POST.get('search_text')
        print(search_text)
    else:
        search_text=''
    valid=Place.objects.filter(name__contains= search_text)
    
    print("searching ", search_text)
    print("valid :",valid)
    return render(request,'ajax_search.html',{'skills':valid})
    
def ms(request):
    return render(request,'ms1.html')

def gal(request):
    return render(request,'gallery.html')
def new_user(request):
    if response.method == "POST":
        form = RegisterForm(response.POST)
        if form.is_valid():
            form.save()

        return redirect("/home")
    else:
        form = RegisterForm()
    
    return render(response, "register/register.html", {"form":form})
    return render(request,'recommend.html')
def wayanad(request):
    return render(request,'wayanad.html')

def recommend_place(request):
    inp = "53"
    out= run([sys.executable,'C:/Users/Keerthi Priya/Desktop/semester notes/sem-6/WT-2/project/final/recommend.py',inp,'5'],shell=False,stdout=PIPE)
    print(out)
    data = out.stdout.decode('utf-8')
    data = data.split('\n')
    print((data))
    for i in range(len(data)):
        data[i] = data[i][:-1]
    
    data = data[:5]
    print((data))
    return render(request,'rec.html',{'data1':data})
   
def recommend1_place(request):
    try:
        user = User.objects.get(username=request.user.username)
        user = request.user
        inp = str(user.id)
        #inp = "53"
        if request.path == '/recommend':
            k = '5'
        else:
            k = '10'
        out= run([sys.executable,'C:/Users/Keerthi Priya/Desktop/semester notes/sem-6/WT-2/project/final/recommend.py',inp,k],shell=False,stdout=PIPE)
        
        data = out.stdout.decode('utf-8')
        if( "nouser" in data):
            print("yes")
            return redirect("/new_user")
        else:    
            data = data.split('\n')
            
            for i in range(len(data)):
                data[i] = data[i][:-1]
            user = User.objects.get(username=request.user.username)
            user = request.user
            data = data[:int(k)]
            print(user.id)
            return render(request,'rec.html',{'data1':data})
    except:
        return redirect("/login")
