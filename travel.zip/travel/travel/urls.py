from django.conf.urls import url,include
from django.conf.urls.static import static
from django.contrib import admin
from django.contrib import admin
from django.urls import path, include
from . import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf import settings
from register import views as v
urlpatterns = [
url(r'^admin/', admin.site.urls),
url(r'^$', views.wt_home),

url('wt_home',views.wt_home),
url('home',views.wt_home,name = "home"),
url('base',views.base),
url('gallery',views.gal,name = "gallery"),
url('ms',views.ms,name = "ms"),
url('PONDICHERRY',views.ms,name = "PONDICHERRY"),
url('DARJEELING',views.ms,name = "DARJEELING"),
url('RAJASTHAN',views.ms,name = "RAJASTHAN"),
url('Nilachal Hills',views.ms,name = "Nilachal Hills"),
url('SHIRDI and AURANGABAD',views.ms,name = "SHIRDI and AURANGABAD"),
url('recommend',views.recommend1_place,name = "recommend"),
url('recommend1',views.recommend1_place,name = "recommend1"),
url('new_user',v.recommend_place,name = "new_user"),
url('add_place',v.add_place),
url(r'^register/', v.register,name = "register"),
path('', include("django.contrib.auth.urls")),
path('search/',views.search_titles,name = "search"),

]

urlpatterns += staticfiles_urlpatterns()
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)