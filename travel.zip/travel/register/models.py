from django.db import models
from multiselectfield import MultiSelectField
# Create your models here.
from django.db import models
from django.contrib.auth.models import User
'''
class UserProfile(models.Model):
	user = models.OneToOneField(User,on_delete = models.CASCADE)
	user_id = models.AutoField()'''

class Place(models.Model):
	Types = (('HISTORIC','HISTORIC'),('FAMILY','FAMILY'),('SOLO TRAVEL','SOLO TRAVEL'),('BEACH','BEACH'),('ADVENTUROUS','ADVENTUROUS'),('FRIENDS','FRIENDS'),('ZOO AND NATURAL PARKS','ZOO AND NATURAL PARKS'))
	name = models.CharField(max_length=50,default = 'place')
	Type = 	models.CharField(choices = Types,default = 'FAMILY',max_length = 128)
	


class Recommend(models.Model):
	Types = (('HISTORIC','HISTORIC'),('FAMILY','FAMILY'),('SOLO TRAVEL','SOLO TRAVEL'),('BEACH','BEACH'),('ADVENTUROUS','ADVENTUROUS'),('FRIENDS','FRIENDS'),('ZOO AND NATURAL PARKS','ZOO AND NATURAL PARKS'))
	Type = 	MultiSelectField(choices = Types)
	
