# views.py
from django.shortcuts import render, redirect
from .forms import RegisterForm
from register.models import Place
from .forms import PlacesForm,RecommendForm
# Create your views here.
def register(response):
	if response.method == "POST":
		form = RegisterForm(response.POST)
		if form.is_valid():
			form.save()

		return redirect("/home")
	else:
		form = RegisterForm()
	
	return render(response, "register/register.html", {"form":form})

def add_place(response):
	if response.method == "POST":
		form = PlacesForm(response.POST)
		if form.is_valid():
			form.save()

		return redirect("/home")
	else:
		form = PlacesForm()
	
	return render(response, "add_place.html", {"form":form})
def recommend_place(response):
	if response.method == "POST":
		form = RecommendForm(response.POST)
		if form.is_valid():
			form.save()
			type1 = response.POST.getlist('Type')
			data1 = []
			data = Place.objects.filter(Type__in = type1  )
			for i in data:
				data1.append(i.name) 
			#print("type ",type1)
			#print(data)
			return render(response, "rec.html", {"data1":data1})	
	else:
		form = RecommendForm()
	
	return render(response, "recommend.html", {"form":form})