from django.contrib import admin

# Register your models here.
from .models import Place,Recommend#,UserProfile

admin.site.register(Place)
admin.site.register(Recommend)
#admin.site.register(UserProfile)